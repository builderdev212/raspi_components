class BuzzerError(Exception):
    """
    Raised when there is an error while working with the Buzzer class.
    """
    def __init__(self):
        pass
